
import React, { useState, useEffect } from "react";

export default function JuicerShopApp() {
  const [cart, setCart] = useState([]);
  const [orders, setOrders] = useState(() => {
    const saved = localStorage.getItem("orders");
    return saved ? JSON.parse(saved) : [];
  });
  const [showCheckout, setShowCheckout] = useState(false);
  const [customer, setCustomer] = useState({ name: "", phone: "", address: "" });
  const [products] = useState([
    { id: 1, name: "Juicer Machine", price: 120, image: "https://via.placeholder.com/200" },
    { id: 2, name: "Blender", price: 80, image: "https://via.placeholder.com/200" },
    { id: 3, name: "Kitchen Processor", price: 150, image: "https://via.placeholder.com/200" },
  ]);

  useEffect(() => {
    localStorage.setItem("orders", JSON.stringify(orders));
  }, [orders]);

  const addToCart = (product) => {
    setCart((prev) => [...prev, product]);
  };

  const removeFromCart = (index) => {
    setCart((prev) => prev.filter((_, i) => i !== index));
  };

  const placeOrder = () => {
    if (!customer.name || !customer.phone || !customer.address) {
      alert("Please fill in all fields");
      return;
    }
    const newOrder = {
      id: Date.now(),
      customer,
      items: cart,
      total: cart.reduce((sum, item) => sum + item.price, 0),
    };
    setOrders([...orders, newOrder]);
    setCart([]);
    setCustomer({ name: "", phone: "", address: "" });
    setShowCheckout(false);
    alert("Order placed successfully!");
  };

  return (
    <div className="p-4 max-w-4xl mx-auto">
      <h1 className="text-3xl font-bold mb-4">Juicer Shop</h1>

      {/* Products */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {products.map((p) => (
          <div key={p.id} className="border rounded-xl p-4 shadow">
            <img src={p.image} alt={p.name} className="w-full h-40 object-cover rounded-md" />
            <h2 className="text-lg font-semibold mt-2">{p.name}</h2>
            <p className="text-gray-600">${p.price}</p>
            <button
              onClick={() => addToCart(p)}
              className="mt-2 bg-blue-600 text-white px-3 py-1 rounded-lg"
            >
              Add to Cart
            </button>
          </div>
        ))}
      </div>

      {/* Cart */}
      <h2 className="text-2xl font-bold mt-6">Cart</h2>
      {cart.length === 0 ? (
        <p>No items in cart.</p>
      ) : (
        <ul className="list-disc pl-6">
          {cart.map((item, i) => (
            <li key={i} className="flex justify-between items-center">
              {item.name} - ${item.price}
              <button
                onClick={() => removeFromCart(i)}
                className="text-red-500 ml-2"
              >
                Remove
              </button>
            </li>
          ))}
        </ul>
      )}
      {cart.length > 0 && (
        <button
          onClick={() => setShowCheckout(true)}
          className="mt-4 bg-green-600 text-white px-4 py-2 rounded-lg"
        >
          Proceed to Checkout
        </button>
      )}

      {/* Checkout */}
      {showCheckout && (
        <div className="mt-6 border p-4 rounded-xl shadow bg-gray-50">
          <h3 className="text-xl font-bold mb-2">Checkout</h3>
          <input
            type="text"
            placeholder="Name"
            value={customer.name}
            onChange={(e) => setCustomer({ ...customer, name: e.target.value })}
            className="block border p-2 w-full mb-2 rounded"
          />
          <input
            type="text"
            placeholder="Phone"
            value={customer.phone}
            onChange={(e) => setCustomer({ ...customer, phone: e.target.value })}
            className="block border p-2 w-full mb-2 rounded"
          />
          <textarea
            placeholder="Address"
            value={customer.address}
            onChange={(e) => setCustomer({ ...customer, address: e.target.value })}
            className="block border p-2 w-full mb-2 rounded"
          />
          <button
            onClick={placeOrder}
            className="bg-blue-600 text-white px-4 py-2 rounded-lg"
          >
            Place Order
          </button>
        </div>
      )}

      {/* Orders */}
      <h2 className="text-2xl font-bold mt-6">Order History</h2>
      {orders.length === 0 ? (
        <p>No past orders.</p>
      ) : (
        <ul className="space-y-2">
          {orders.map((o) => (
            <li key={o.id} className="border p-2 rounded shadow-sm">
              <p><strong>Order #{o.id}</strong></p>
              <p>Customer: {o.customer.name}</p>
              <p>Phone: {o.customer.phone}</p>
              <p>Address: {o.customer.address}</p>
              <p>Total: ${o.total}</p>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
